package com.example

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.unit.dp
import com.example.data.local.TaskEntity
import com.example.ui.dashboard.DailyTimeline
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun dashboard_timeline_screenshot() {
    val sampleTasks = listOf(
      TaskEntity(
        id = 1,
        title = "حل تمارين الدوال",
        subject = "الرياضيات",
        startTime = "08:00",
        endTime = "09:30",
        durationMinutes = 90,
        priority = "مرتفع",
        isAlarmEnabled = true,
        date = "2026-09-05"
      ),
      TaskEntity(
        id = 2,
        title = "مراجعة قوانين الحركة",
        subject = "الفيزياء",
        startTime = "10:00",
        endTime = "11:00",
        durationMinutes = 60,
        priority = "متوسط",
        isAlarmEnabled = false,
        date = "2026-09-05"
      )
    )

    composeTestRule.setContent {
      MyApplicationTheme {
        Box(modifier = Modifier.padding(16.dp)) {
          DailyTimeline(tasks = sampleTasks)
        }
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/timeline.png")
  }
}

