package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.TaskEntity
import com.example.security.SecurityManager
import com.example.suggestions.SmartSuggestionEngine
import com.example.timer.TimerPresets
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("منظّم الدراسة", appName)
  }

  @Test
  fun `security manager hashes and verifies pin accurately`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val sec = SecurityManager(context)
    sec.resetPin()
    assertFalse(sec.hasSetPin())

    sec.savePin("1234")
    assertTrue(sec.hasSetPin())
    assertTrue(sec.verifyPin("1234"))
    assertFalse(sec.verifyPin("9999"))
  }

  @Test
  fun `smart suggestions engine detects long tasks and gaps`() {
    val tasks = listOf(
      TaskEntity(
        id = 1,
        title = "حل تمارين الرياضيات",
        subject = "الرياضيات",
        startTime = "08:00",
        endTime = "09:45",
        durationMinutes = 105,
        priority = "مرتفع",
        date = "2026-09-05"
      ),
      TaskEntity(
        id = 2,
        title = "مراجعة الفيزياء",
        subject = "الفيزياء",
        startTime = "09:50",
        endTime = "11:00",
        durationMinutes = 70,
        priority = "عاجل",
        date = "2026-09-05"
      )
    )

    val suggestions = SmartSuggestionEngine.generateSuggestions(tasks)
    assertTrue(suggestions.size in 5..10)
    assertTrue(suggestions.any { it.text.contains("90 دقيقة") || it.text.contains("متتاليتان") })
  }

  @Test
  fun `timer presets are correctly configured`() {
    assertEquals(25, TimerPresets.Pomodoro.focusMinutes)
    assertEquals(5, TimerPresets.Pomodoro.breakMinutes)
    assertEquals(50, TimerPresets.Method50_10.focusMinutes)
    assertEquals(10, TimerPresets.Method50_10.breakMinutes)
    assertEquals(90, TimerPresets.Method90_20.focusMinutes)
    assertEquals(20, TimerPresets.Method90_20.breakMinutes)
  }
}

