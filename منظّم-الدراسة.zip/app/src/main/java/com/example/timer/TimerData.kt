package com.example.timer

enum class TimerSessionType {
    FOCUS,
    BREAK
}

enum class TimerRunState {
    STOPPED,
    RUNNING,
    PAUSED,
    FOCUS_COMPLETED,
    BREAK_COMPLETED
}

data class TimerMethod(
    val id: String,
    val title: String,
    val arabicTitle: String,
    val focusMinutes: Int,
    val breakMinutes: Int,
    val totalCycles: Int,
    val descriptionArabic: String
)

object TimerPresets {
    val Pomodoro = TimerMethod(
        id = "pomodoro",
        title = "Pomodoro",
        arabicTitle = "طريقة بومودورو",
        focusMinutes = 25,
        breakMinutes = 5,
        totalCycles = 4,
        descriptionArabic = "25 دقيقة تركيز متبوعة بـ 5 دقائق استراحة. من أشهر الأساليب لتجنب التشتت والإرهاق الذهني."
    )

    val Method50_10 = TimerMethod(
        id = "50_10",
        title = "50 / 10",
        arabicTitle = "طريقة 50 / 10",
        focusMinutes = 50,
        breakMinutes = 10,
        totalCycles = 4,
        descriptionArabic = "50 دقيقة تركيز عميق تليها 10 دقائق استراحة. ممتازة لجلسات المحاضرات وحل المسائل الطويلة."
    )

    val Method90_20 = TimerMethod(
        id = "90_20",
        title = "90 / 20",
        arabicTitle = "طريقة 90 / 20",
        focusMinutes = 90,
        breakMinutes = 20,
        totalCycles = 3,
        descriptionArabic = "90 دقيقة تركيز تليها 20 دقيقة استراحة. متوافقة مع دورات التركيز الطبيعية في المهام المكثفة."
    )

    val Method52_17 = TimerMethod(
        id = "52_17",
        title = "52 / 17",
        arabicTitle = "طريقة 52 / 17",
        focusMinutes = 52,
        breakMinutes = 17,
        totalCycles = 4,
        descriptionArabic = "52 دقيقة عمل متبوعة بـ 17 دقيقة راحة كاملة. أسلوب شائع لدى العديد من الطلاب المحترفين."
    )

    fun createCustom(focusMinutes: Int, breakMinutes: Int): TimerMethod {
        return TimerMethod(
            id = "custom",
            title = "Custom",
            arabicTitle = "مخصص ($focusMinutes / $breakMinutes)",
            focusMinutes = focusMinutes,
            breakMinutes = breakMinutes,
            totalCycles = 4,
            descriptionArabic = "تحديد مخصص للمدة التي تفضلها للتركيز والاستراحة وفقاً لجدولك الدراسي."
        )
    }

    val allPresets = listOf(Pomodoro, Method50_10, Method90_20, Method52_17)
}
