package com.example.timer

import android.os.CountDownTimer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class TimerUIState(
    val currentMethod: TimerMethod = TimerPresets.Pomodoro,
    val sessionType: TimerSessionType = TimerSessionType.FOCUS,
    val runState: TimerRunState = TimerRunState.STOPPED,
    val currentCycle: Int = 1,
    val remainingSeconds: Long = 25 * 60L,
    val totalSecondsForCurrentPhase: Long = 25 * 60L,
    val linkedTaskId: Long? = null,
    val subjectName: String = "الرياضيات",
    val taskTitle: String = "جلسة تركيز دراسية",
    val autoTransition: Boolean = false
) {
    val progress: Float
        get() = if (totalSecondsForCurrentPhase > 0) {
            (totalSecondsForCurrentPhase - remainingSeconds).toFloat() / totalSecondsForCurrentPhase.toFloat()
        } else 0f

    val formattedTime: String
        get() {
            val minutes = remainingSeconds / 60
            val seconds = remainingSeconds % 60
            return "%02d:%02d".format(minutes, seconds)
        }
}

class TimerManager {

    private val _state = MutableStateFlow(TimerUIState())
    val state: StateFlow<TimerUIState> = _state.asStateFlow()

    private var countDownTimer: CountDownTimer? = null
    private var targetEpochMillis: Long = 0L

    fun configureMethod(
        method: TimerMethod,
        subject: String = "جلسة دراسة",
        taskTitle: String = "",
        taskId: Long? = null,
        autoTransition: Boolean = false
    ) {
        stopTimer()
        val initialFocusSeconds = method.focusMinutes * 60L
        _state.value = TimerUIState(
            currentMethod = method,
            sessionType = TimerSessionType.FOCUS,
            runState = TimerRunState.STOPPED,
            currentCycle = 1,
            remainingSeconds = initialFocusSeconds,
            totalSecondsForCurrentPhase = initialFocusSeconds,
            linkedTaskId = taskId,
            subjectName = subject,
            taskTitle = taskTitle.ifBlank { "جلسة تركيز دراسية" },
            autoTransition = autoTransition
        )
    }

    fun startTaskSession(
        taskId: Long,
        subject: String,
        taskTitle: String,
        durationMinutes: Int,
        autoTransition: Boolean = false
    ) {
        val customMethod = TimerPresets.createCustom(
            focusMinutes = durationMinutes.coerceIn(5, 180),
            breakMinutes = (durationMinutes / 5).coerceIn(5, 20)
        )
        configureMethod(
            method = customMethod,
            subject = subject,
            taskTitle = taskTitle,
            taskId = taskId,
            autoTransition = autoTransition
        )
        startOrResumeTimer()
    }

    fun startOrResumeTimer() {
        val current = _state.value
        val secondsToRun = current.remainingSeconds
        if (secondsToRun <= 0) return

        targetEpochMillis = System.currentTimeMillis() + (secondsToRun * 1000L)
        _state.value = current.copy(runState = TimerRunState.RUNNING)

        countDownTimer?.cancel()
        countDownTimer = object : CountDownTimer(secondsToRun * 1000L, 500L) {
            override fun onTick(millisUntilFinished: Long) {
                // Background-accurate calculation based on epoch time
                val realRemaining = ((targetEpochMillis - System.currentTimeMillis() + 999L) / 1000L).coerceAtLeast(0L)
                _state.value = _state.value.copy(
                    remainingSeconds = realRemaining,
                    runState = TimerRunState.RUNNING
                )
            }

            override fun onFinish() {
                onPhaseCompleted()
            }
        }.start()
    }

    fun pauseTimer() {
        countDownTimer?.cancel()
        val realRemaining = ((targetEpochMillis - System.currentTimeMillis() + 999L) / 1000L).coerceAtLeast(0L)
        _state.value = _state.value.copy(
            remainingSeconds = realRemaining,
            runState = TimerRunState.PAUSED
        )
    }

    fun stopTimer() {
        countDownTimer?.cancel()
        countDownTimer = null
        val current = _state.value
        val resetSeconds = if (current.sessionType == TimerSessionType.FOCUS) {
            current.currentMethod.focusMinutes * 60L
        } else {
            current.currentMethod.breakMinutes * 60L
        }
        _state.value = current.copy(
            runState = TimerRunState.STOPPED,
            remainingSeconds = resetSeconds,
            totalSecondsForCurrentPhase = resetSeconds
        )
    }

    fun addFiveMinutes() {
        val addedSeconds = 5 * 60L
        val current = _state.value
        val newRemaining = current.remainingSeconds + addedSeconds
        val newTotal = current.totalSecondsForCurrentPhase + addedSeconds

        if (current.runState == TimerRunState.RUNNING) {
            targetEpochMillis += (addedSeconds * 1000L)
        }

        _state.value = current.copy(
            remainingSeconds = newRemaining,
            totalSecondsForCurrentPhase = newTotal
        )
    }

    private fun onPhaseCompleted() {
        countDownTimer?.cancel()
        val current = _state.value
        if (current.sessionType == TimerSessionType.FOCUS) {
            // Focus period completed!
            _state.value = current.copy(
                remainingSeconds = 0,
                runState = TimerRunState.FOCUS_COMPLETED
            )
            if (current.autoTransition) {
                startBreak()
            }
        } else {
            // Break completed!
            _state.value = current.copy(
                remainingSeconds = 0,
                runState = TimerRunState.BREAK_COMPLETED
            )
            if (current.autoTransition) {
                startNextFocusCycle()
            }
        }
    }

    fun startBreak() {
        countDownTimer?.cancel()
        val current = _state.value
        val breakSeconds = current.currentMethod.breakMinutes * 60L
        _state.value = current.copy(
            sessionType = TimerSessionType.BREAK,
            runState = TimerRunState.STOPPED,
            remainingSeconds = breakSeconds,
            totalSecondsForCurrentPhase = breakSeconds
        )
        startOrResumeTimer()
    }

    fun skipBreak() {
        startNextFocusCycle()
    }

    fun startNextFocusCycle() {
        countDownTimer?.cancel()
        val current = _state.value
        val nextCycle = current.currentCycle + 1
        val focusSeconds = current.currentMethod.focusMinutes * 60L
        _state.value = current.copy(
            sessionType = TimerSessionType.FOCUS,
            currentCycle = nextCycle,
            runState = TimerRunState.STOPPED,
            remainingSeconds = focusSeconds,
            totalSecondsForCurrentPhase = focusSeconds
        )
        startOrResumeTimer()
    }
}
