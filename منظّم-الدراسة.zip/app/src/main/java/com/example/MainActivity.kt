package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.repository.TaskRepository
import com.example.ui.MainViewModel
import com.example.ui.auth.CreatePinScreen
import com.example.ui.auth.PinLoginScreen
import com.example.ui.auth.WelcomeScreen
import com.example.ui.dashboard.MainDashboardScreen
import com.example.ui.dashboard.TaskDialog
import com.example.ui.navigation.Screen
import com.example.ui.settings.SettingsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.timer.ActiveTimerScreen
import com.example.ui.timer.TimerMethodSelectScreen

class MainActivity : ComponentActivity() {

    private var pendingTaskId: Long? = null
    private var pendingTaskTitle: String? = null
    private var pendingTaskSubject: String? = null
    private var pendingTaskDuration: Int = 60

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        extractIntentExtras(intent)

        setContent {
            val app = application as StudyPlannerApp
            val repository = remember {
                TaskRepository(app.database.taskDao(), app.alarmScheduler)
            }

            val viewModel: MainViewModel = viewModel(
                factory = object : ViewModelProvider.Factory {
                    @Suppress("UNCHECKED_CAST")
                    override fun <T : ViewModel> create(modelClass: Class<T>): T {
                        return MainViewModel(
                            repository = repository,
                            securityManager = app.securityManager
                        ) as T
                    }
                }
            )

            // Request Notification Permission on Android 13+
            val permissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestPermission()
            ) { _ -> }

            LaunchedEffect(Unit) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    val hasPermission = ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.POST_NOTIFICATIONS
                    ) == PackageManager.PERMISSION_GRANTED
                    if (!hasPermission) {
                        permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
            }

            // Handle direct alarm click
            LaunchedEffect(pendingTaskId) {
                val taskId = pendingTaskId
                if (taskId != null) {
                    val subject = pendingTaskSubject ?: "جلسة دراسة"
                    val title = pendingTaskTitle ?: ""
                    viewModel.timerManager.startTaskSession(
                        taskId = taskId,
                        subject = subject,
                        taskTitle = title,
                        durationMinutes = pendingTaskDuration,
                        autoTransition = viewModel.autoBreakEnabled.value
                    )
                    viewModel.navigateTo(Screen.ActiveTimer)
                    pendingTaskId = null
                }
            }

            // Theme Mode
            val themeMode by viewModel.themeMode.collectAsState()
            val isDark = when (themeMode) {
                "dark" -> true
                "light" -> false
                else -> isSystemInDarkTheme()
            }

            MyApplicationTheme(darkTheme = isDark) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppNavigationHost(viewModel = viewModel)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        extractIntentExtras(intent)
    }

    private fun extractIntentExtras(intent: Intent?) {
        if (intent?.getBooleanExtra("ACTION_START_TASK_TIMER", false) == true) {
            pendingTaskId = intent.getLongExtra("EXTRA_TASK_ID", -1L).takeIf { it > 0 }
            pendingTaskTitle = intent.getStringExtra("EXTRA_TASK_TITLE")
            pendingTaskSubject = intent.getStringExtra("EXTRA_TASK_SUBJECT")
            pendingTaskDuration = intent.getIntExtra("EXTRA_TASK_DURATION", 60)
        }
    }
}

@Composable
fun AppNavigationHost(viewModel: MainViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val authError by viewModel.authError.collectAsState()
    val todayTasks by viewModel.todayTasks.collectAsState()
    val suggestions by viewModel.smartSuggestions.collectAsState()
    val selectedTab by viewModel.selectedTab.collectAsState()
    val notificationMessage by viewModel.notificationMessage.collectAsState()
    val timerState by viewModel.timerManager.state.collectAsState()
    val taskDialogState by viewModel.taskDialogState.collectAsState()
    val themeMode by viewModel.themeMode.collectAsState()
    val autoBreak by viewModel.autoBreakEnabled.collectAsState()

    // Handle back presses smoothly
    BackHandler(enabled = currentScreen !in listOf(Screen.Welcome, Screen.PinLogin, Screen.Dashboard)) {
        when (currentScreen) {
            Screen.CreatePin -> viewModel.navigateTo(Screen.Welcome)
            Screen.TimerMethodSelect -> viewModel.navigateTo(Screen.Dashboard)
            Screen.ActiveTimer -> viewModel.navigateTo(Screen.TimerMethodSelect)
            Screen.Settings -> viewModel.navigateTo(Screen.Dashboard)
            else -> viewModel.navigateTo(Screen.Dashboard)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        when (currentScreen) {
            Screen.Welcome -> {
                WelcomeScreen(
                    onGoogleAuthSuccess = { name, email ->
                        viewModel.onGoogleSignInSuccess(name, email)
                    },
                    onDirectPinLoginClick = {
                        viewModel.navigateTo(Screen.PinLogin)
                    }
                )
            }

            Screen.GoogleAuth -> {
                WelcomeScreen(
                    onGoogleAuthSuccess = { name, email ->
                        viewModel.onGoogleSignInSuccess(name, email)
                    },
                    onDirectPinLoginClick = {
                        viewModel.navigateTo(Screen.PinLogin)
                    }
                )
            }

            Screen.CreatePin -> {
                CreatePinScreen(
                    errorMessage = authError,
                    onCreatePin = { pin, confirmPin ->
                        viewModel.onCreatePin(pin, confirmPin)
                    }
                )
            }

            Screen.PinLogin -> {
                PinLoginScreen(
                    errorMessage = authError,
                    onLogin = { pin ->
                        viewModel.onPinLogin(pin)
                    },
                    onForgotPin = {
                        viewModel.onForgotPinReset()
                    }
                )
            }

            Screen.Dashboard -> {
                MainDashboardScreen(
                    userName = viewModel.getUserName(),
                    todayDateFormatted = viewModel.todayDateFormatted,
                    tasks = todayTasks,
                    suggestions = suggestions,
                    selectedTab = selectedTab,
                    notificationMessage = notificationMessage,
                    onClearNotification = { viewModel.clearNotificationMessage() },
                    onTabSelected = { tab -> viewModel.selectTab(tab) },
                    onAddTaskClick = { viewModel.openAddTaskDialog() },
                    onEditTask = { task -> viewModel.openEditTaskDialog(task) },
                    onDeleteTask = { task -> viewModel.deleteTask(task) },
                    onToggleCompletion = { task -> viewModel.toggleTaskCompletion(task) },
                    onToggleAlarm = { task -> viewModel.toggleTaskAlarm(task) },
                    onStartTimer = { task -> viewModel.startTaskTimer(task) },
                    onSuggestionAction = { suggestion -> viewModel.handleSuggestionAction(suggestion) },
                    onOpenSettings = { viewModel.navigateTo(Screen.Settings) }
                )
            }

            Screen.TimerMethodSelect -> {
                TimerMethodSelectScreen(
                    onSelectMethod = { method, subject ->
                        viewModel.selectTimerMethod(method, subject)
                    },
                    onBackToDashboard = {
                        viewModel.navigateTo(Screen.Dashboard)
                        viewModel.selectTab(0)
                    }
                )
            }

            Screen.ActiveTimer -> {
                ActiveTimerScreen(
                    timerState = timerState,
                    onStartResume = { viewModel.timerManager.startOrResumeTimer() },
                    onPause = { viewModel.timerManager.pauseTimer() },
                    onAddFiveMinutes = { viewModel.timerManager.addFiveMinutes() },
                    onStartBreak = { viewModel.timerManager.startBreak() },
                    onSkipBreak = { viewModel.timerManager.skipBreak() },
                    onStartNextFocusCycle = { viewModel.timerManager.startNextFocusCycle() },
                    onFinishSession = { viewModel.finishCurrentSession() },
                    onCloseToDashboard = {
                        viewModel.navigateTo(Screen.Dashboard)
                        viewModel.selectTab(0)
                    }
                )
            }

            Screen.Settings -> {
                SettingsScreen(
                    userName = viewModel.getUserName(),
                    userEmail = viewModel.getUserEmail(),
                    currentThemeMode = themeMode,
                    autoBreakEnabled = autoBreak,
                    onThemeModeChange = { mode -> viewModel.setDarkThemeMode(mode) },
                    onAutoBreakChange = { enabled -> viewModel.setAutoBreak(enabled) },
                    onLockSession = { viewModel.logout() },
                    onResetPassword = { viewModel.onForgotPinReset() },
                    onBack = { viewModel.navigateTo(Screen.Dashboard) }
                )
            }
        }

        // Task Add/Edit Dialog
        if (taskDialogState.isOpen) {
            TaskDialog(
                taskToEdit = taskDialogState.taskToEdit,
                onDismiss = { viewModel.closeTaskDialog() },
                onSave = { title, subject, start, end, priority, notes, alarm ->
                    viewModel.saveTask(title, subject, start, end, priority, notes, alarm)
                }
            )
        }
    }
}

