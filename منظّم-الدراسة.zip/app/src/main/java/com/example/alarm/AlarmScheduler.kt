package com.example.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.data.local.TaskEntity
import com.example.receiver.TaskAlarmReceiver
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

class AlarmScheduler(private val context: Context) {

    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager

    fun scheduleTaskAlarm(task: TaskEntity) {
        if (!task.isAlarmEnabled || task.isCompleted || alarmManager == null) {
            cancelTaskAlarm(task.id)
            return
        }

        try {
            val (hour, minute) = parseTime(task.startTime)
            val now = LocalDateTime.now()
            var taskDateTime = LocalDateTime.of(
                LocalDate.now(),
                LocalTime.of(hour, minute)
            )

            // If time has passed today, schedule for next occurrence or skip
            if (taskDateTime.isBefore(now)) {
                taskDateTime = taskDateTime.plusDays(1)
            }

            val triggerMillis = taskDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

            val intent = Intent(context, TaskAlarmReceiver::class.java).apply {
                putExtra(TaskAlarmReceiver.EXTRA_TASK_ID, task.id)
                putExtra(TaskAlarmReceiver.EXTRA_TASK_TITLE, task.title)
                putExtra(TaskAlarmReceiver.EXTRA_TASK_SUBJECT, task.subject)
                putExtra(TaskAlarmReceiver.EXTRA_TASK_DURATION, task.durationMinutes)
            }

            val pendingIntent = PendingIntent.getBroadcast(
                context,
                task.id.toInt(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    triggerMillis,
                    pendingIntent
                )
            }
            Log.d("AlarmScheduler", "Alarm scheduled for task ${task.id} at $taskDateTime")
        } catch (e: Exception) {
            Log.e("AlarmScheduler", "Failed to schedule alarm for task ${task.id}", e)
        }
    }

    fun cancelTaskAlarm(taskId: Long) {
        if (alarmManager == null) return
        try {
            val intent = Intent(context, TaskAlarmReceiver::class.java)
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                taskId.toInt(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
            Log.d("AlarmScheduler", "Alarm cancelled for task $taskId")
        } catch (e: Exception) {
            Log.e("AlarmScheduler", "Failed to cancel alarm for task $taskId", e)
        }
    }

    private fun parseTime(timeStr: String): Pair<Int, Int> {
        val parts = timeStr.trim().split(":")
        val hour = parts.getOrNull(0)?.toIntOrNull() ?: 8
        val minute = parts.getOrNull(1)?.toIntOrNull() ?: 0
        return Pair(hour.coerceIn(0, 23), minute.coerceIn(0, 59))
    }
}
