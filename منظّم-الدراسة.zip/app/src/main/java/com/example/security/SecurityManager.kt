package com.example.security

import android.content.Context
import android.content.SharedPreferences
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64

class SecurityManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("study_planner_secure_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_PIN_HASH = "key_pin_hash"
        private const val KEY_PIN_SALT = "key_pin_salt"
        private const val KEY_USER_LOGGED_IN = "key_user_logged_in"
        private const val KEY_USER_NAME = "key_user_name"
        private const val KEY_USER_EMAIL = "key_user_email"
        private const val KEY_GOOGLE_AUTH_DONE = "key_google_auth_done"
        private const val KEY_DARK_THEME_MODE = "key_dark_theme_mode" // "system", "light", "dark"
        private const val KEY_AUTO_BREAK = "key_auto_break"
    }

    fun hasSetPin(): Boolean {
        return prefs.contains(KEY_PIN_HASH) && prefs.contains(KEY_PIN_SALT)
    }

    fun isGoogleAuthDone(): Boolean {
        return prefs.getBoolean(KEY_GOOGLE_AUTH_DONE, false)
    }

    fun setGoogleAuthDone(userName: String, userEmail: String) {
        prefs.edit()
            .putBoolean(KEY_GOOGLE_AUTH_DONE, true)
            .putString(KEY_USER_NAME, userName)
            .putString(KEY_USER_EMAIL, userEmail)
            .apply()
    }

    fun savePin(pin: String) {
        val random = SecureRandom()
        val saltBytes = ByteArray(16)
        random.nextBytes(saltBytes)
        val saltBase64 = Base64.getEncoder().encodeToString(saltBytes)

        val hash = hashPin(pin, saltBytes)

        prefs.edit()
            .putString(KEY_PIN_SALT, saltBase64)
            .putString(KEY_PIN_HASH, hash)
            .putBoolean(KEY_USER_LOGGED_IN, true)
            .apply()
    }

    fun verifyPin(pin: String): Boolean {
        val saltBase64 = prefs.getString(KEY_PIN_SALT, null) ?: return false
        val savedHash = prefs.getString(KEY_PIN_HASH, null) ?: return false

        val saltBytes = try {
            Base64.getDecoder().decode(saltBase64)
        } catch (e: Exception) {
            return false
        }

        val computedHash = hashPin(pin, saltBytes)
        val matches = computedHash == savedHash
        if (matches) {
            prefs.edit().putBoolean(KEY_USER_LOGGED_IN, true).apply()
        }
        return matches
    }

    fun resetPin() {
        prefs.edit()
            .remove(KEY_PIN_HASH)
            .remove(KEY_PIN_SALT)
            .putBoolean(KEY_USER_LOGGED_IN, false)
            .apply()
    }

    fun isUserSessionActive(): Boolean {
        return prefs.getBoolean(KEY_USER_LOGGED_IN, false)
    }

    fun lockSession() {
        prefs.edit().putBoolean(KEY_USER_LOGGED_IN, false).apply()
    }

    fun getUserName(): String {
        return prefs.getString(KEY_USER_NAME, "طالب المعرفة") ?: "طالب المعرفة"
    }

    fun getUserEmail(): String {
        return prefs.getString(KEY_USER_EMAIL, "student@university.edu") ?: "student@university.edu"
    }

    fun getDarkThemeMode(): String {
        return prefs.getString(KEY_DARK_THEME_MODE, "dark") ?: "dark"
    }

    fun setDarkThemeMode(mode: String) {
        prefs.edit().putString(KEY_DARK_THEME_MODE, mode).apply()
    }

    fun isAutoBreakEnabled(): Boolean {
        return prefs.getBoolean(KEY_AUTO_BREAK, false)
    }

    fun setAutoBreakEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_AUTO_BREAK, enabled).apply()
    }

    private fun hashPin(pin: String, salt: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(salt)
        val hashedBytes = digest.digest(pin.toByteArray(Charsets.UTF_8))
        return hashedBytes.joinToString("") { "%02x".format(it) }
    }
}
