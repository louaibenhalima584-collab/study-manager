package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "timer_sessions")
data class TimerSessionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val taskId: Long? = null,
    val subject: String,
    val taskTitle: String = "",
    val methodName: String,
    val focusMinutes: Int,
    val breakMinutes: Int,
    val completedCycles: Int = 1,
    val completedAt: Long = System.currentTimeMillis()
)
