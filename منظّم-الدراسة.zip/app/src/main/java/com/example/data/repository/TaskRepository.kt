package com.example.data.repository

import com.example.alarm.AlarmScheduler
import com.example.data.local.TaskDao
import com.example.data.local.TaskEntity
import com.example.data.local.TimerSessionEntity
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

class TaskRepository(
    private val taskDao: TaskDao,
    private val alarmScheduler: AlarmScheduler
) {
    fun getTasksForDate(date: String = LocalDate.now().toString()): Flow<List<TaskEntity>> {
        return taskDao.getTasksForDate(date)
    }

    fun getAllTasks(): Flow<List<TaskEntity>> {
        return taskDao.getAllTasks()
    }

    suspend fun getTaskById(id: Long): TaskEntity? {
        return taskDao.getTaskById(id)
    }

    suspend fun insertTask(task: TaskEntity): Long {
        val id = taskDao.insertTask(task)
        val savedTask = task.copy(id = id)
        if (savedTask.isAlarmEnabled && !savedTask.isCompleted) {
            alarmScheduler.scheduleTaskAlarm(savedTask)
        }
        return id
    }

    suspend fun updateTask(task: TaskEntity) {
        taskDao.updateTask(task)
        if (task.isAlarmEnabled && !task.isCompleted) {
            alarmScheduler.scheduleTaskAlarm(task)
        } else {
            alarmScheduler.cancelTaskAlarm(task.id)
        }
    }

    suspend fun toggleAlarm(taskId: Long, isAlarmEnabled: Boolean) {
        taskDao.updateAlarm(taskId, isAlarmEnabled)
        val task = taskDao.getTaskById(taskId)
        if (task != null) {
            if (isAlarmEnabled && !task.isCompleted) {
                alarmScheduler.scheduleTaskAlarm(task.copy(isAlarmEnabled = true))
            } else {
                alarmScheduler.cancelTaskAlarm(taskId)
            }
        }
    }

    suspend fun toggleCompletion(taskId: Long, isCompleted: Boolean) {
        taskDao.updateCompletion(taskId, isCompleted)
        if (isCompleted) {
            alarmScheduler.cancelTaskAlarm(taskId)
        } else {
            val task = taskDao.getTaskById(taskId)
            if (task != null && task.isAlarmEnabled) {
                alarmScheduler.scheduleTaskAlarm(task)
            }
        }
    }

    suspend fun deleteTask(task: TaskEntity) {
        alarmScheduler.cancelTaskAlarm(task.id)
        taskDao.deleteTask(task)
    }

    suspend fun recordTimerSession(session: TimerSessionEntity): Long {
        return taskDao.insertSession(session)
    }

    fun getAllTimerSessions(): Flow<List<TimerSessionEntity>> {
        return taskDao.getAllSessions()
    }

    suspend fun populateInitialDataIfEmpty() {
        val today = LocalDate.now().toString()
        val existing = taskDao.getTaskById(1)
        if (existing == null) {
            val starterTasks = listOf(
                TaskEntity(
                    title = "مراجعة درس الرياضيات",
                    subject = "الرياضيات",
                    startTime = "16:00",
                    endTime = "17:00",
                    durationMinutes = 60,
                    priority = "مرتفع",
                    notes = "التركيز على تمارين الوحدة الثالثة",
                    isAlarmEnabled = true,
                    isCompleted = true,
                    date = today
                ),
                TaskEntity(
                    title = "قراءة نص في الأدب",
                    subject = "اللغة العربية",
                    startTime = "17:30",
                    endTime = "18:30",
                    durationMinutes = 60,
                    priority = "متوسط",
                    notes = "تحليل الشواهد البلاغية والقصيدة",
                    isAlarmEnabled = false,
                    isCompleted = true,
                    date = today
                ),
                TaskEntity(
                    title = "تمارين الفيزياء",
                    subject = "الفيزياء",
                    startTime = "19:00",
                    endTime = "20:30",
                    durationMinutes = 90,
                    priority = "عاجل",
                    notes = "حل مسائل قوانين نيوتن والميكانيكا",
                    isAlarmEnabled = true,
                    isCompleted = false,
                    date = today
                ),
                TaskEntity(
                    title = "حفظ مفردات الإنجليزية",
                    subject = "اللغة الإنجليزية",
                    startTime = "",
                    endTime = "",
                    durationMinutes = 0,
                    priority = "متوسط",
                    notes = "حفظ الكلمات الجديدة من الوحدة الرابعة",
                    isAlarmEnabled = false,
                    isCompleted = false,
                    date = today
                ),
                TaskEntity(
                    title = "مطالعة كتاب",
                    subject = "قراءة عامة",
                    startTime = "21:00",
                    endTime = "22:00",
                    durationMinutes = 60,
                    priority = "منخفض",
                    notes = "قراءة 20 صفحة لتوسيع الفهم",
                    isAlarmEnabled = false,
                    isCompleted = false,
                    date = today
                )
            )
            starterTasks.forEach { insertTask(it) }
        }
    }
}
