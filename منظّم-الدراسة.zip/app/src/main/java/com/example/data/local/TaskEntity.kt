package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val subject: String,
    val startTime: String, // e.g. "17:00"
    val endTime: String,   // e.g. "18:30"
    val durationMinutes: Int, // e.g. 90
    val priority: String, // "منخفض", "متوسط", "مرتفع", "عاجل"
    val notes: String = "",
    val isAlarmEnabled: Boolean = true,
    val isCompleted: Boolean = false,
    val date: String, // "YYYY-MM-DD"
    val createdAt: Long = System.currentTimeMillis()
)
