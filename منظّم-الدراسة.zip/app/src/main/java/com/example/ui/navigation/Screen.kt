package com.example.ui.navigation

sealed class Screen(val route: String) {
    object Welcome : Screen("welcome")
    object GoogleAuth : Screen("google_auth")
    object CreatePin : Screen("create_pin")
    object PinLogin : Screen("pin_login")
    object Dashboard : Screen("dashboard")
    object TimerMethodSelect : Screen("timer_methods")
    object ActiveTimer : Screen("active_timer")
    object Settings : Screen("settings")
}
