package com.example.ui.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.TaskEntity
import com.example.suggestions.SuggestionItem
import com.example.ui.theme.BorderEspressoDark
import com.example.ui.theme.CardEspressoDark
import com.example.ui.theme.ChipEspressoDark
import com.example.ui.theme.DeepEspressoDark
import com.example.ui.theme.LuxuryGoldAccent
import com.example.ui.theme.LuxuryGoldContainer
import com.example.ui.theme.LuxuryGoldMuted
import com.example.ui.theme.RowEspressoDark
import com.example.ui.theme.TextCreamLight
import com.example.ui.theme.TextGrayMuted
import com.example.ui.theme.TextGraySubtle

@Composable
fun MainDashboardScreen(
    userName: String,
    todayDateFormatted: String,
    tasks: List<TaskEntity>,
    suggestions: List<SuggestionItem>,
    selectedTab: Int,
    notificationMessage: String?,
    onClearNotification: () -> Unit,
    onTabSelected: (Int) -> Unit,
    onAddTaskClick: () -> Unit,
    onEditTask: (TaskEntity) -> Unit,
    onDeleteTask: (TaskEntity) -> Unit,
    onToggleCompletion: (TaskEntity) -> Unit,
    onToggleAlarm: (TaskEntity) -> Unit,
    onStartTimer: (TaskEntity) -> Unit,
    onSuggestionAction: (SuggestionItem) -> Unit,
    onOpenSettings: () -> Unit
) {
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(notificationMessage) {
        if (notificationMessage != null) {
            snackbarHostState.showSnackbar(notificationMessage)
            onClearNotification()
        }
    }

    val totalTasksCount = tasks.size
    val completedCount = tasks.count { it.isCompleted }
    val totalPlannedMinutes = tasks.sumOf { it.durationMinutes }

    val totalHours = totalPlannedMinutes / 60
    val totalRemainderMinutes = totalPlannedMinutes % 60
    val formattedDurationString = when {
        totalHours > 0 && totalRemainderMinutes > 0 -> "${totalHours}س ${totalRemainderMinutes}د"
        totalHours > 0 -> "${totalHours}س"
        else -> "${totalRemainderMinutes}د"
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                // Bottom Navigation Bar
                Surface(
                    color = DeepEspressoDark,
                    tonalElevation = 8.dp,
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderEspressoDark)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // 1. المهام (Tasks) Tab
                        val isTasksSelected = selectedTab == 0 || selectedTab == 1
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onTabSelected(0) }
                                .padding(horizontal = 14.dp, vertical = 4.dp)
                                .testTag("nav_tasks_tab")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Assignment,
                                contentDescription = "المهام",
                                tint = if (isTasksSelected) LuxuryGoldAccent else TextGrayMuted,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "المهام",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 12.sp),
                                fontWeight = if (isTasksSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isTasksSelected) LuxuryGoldAccent else TextGrayMuted
                            )
                            if (isTasksSelected) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Box(
                                    modifier = Modifier
                                        .width(32.dp)
                                        .height(2.5.dp)
                                        .clip(RoundedCornerShape(2.dp))
                                        .background(LuxuryGoldAccent)
                                )
                            }
                        }

                        // 2. المؤقت (Timer) Tab
                        val isTimerSelected = selectedTab == 2
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onTabSelected(2) }
                                .padding(horizontal = 14.dp, vertical = 4.dp)
                                .testTag("nav_timer_tab")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = "المؤقت",
                                tint = if (isTimerSelected) LuxuryGoldAccent else TextGrayMuted,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "المؤقت",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 12.sp),
                                fontWeight = if (isTimerSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isTimerSelected) LuxuryGoldAccent else TextGrayMuted
                            )
                            if (isTimerSelected) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Box(
                                    modifier = Modifier
                                        .width(32.dp)
                                        .height(2.5.dp)
                                        .clip(RoundedCornerShape(2.dp))
                                        .background(LuxuryGoldAccent)
                                )
                            }
                        }

                        // 3. الرئيسية (Home) Tab
                        val isHomeSelected = false
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onTabSelected(0) }
                                .padding(horizontal = 14.dp, vertical = 4.dp)
                                .testTag("nav_home_tab")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Home,
                                contentDescription = "الرئيسية",
                                tint = if (isHomeSelected) LuxuryGoldAccent else TextGrayMuted,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "الرئيسية",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 12.sp),
                                fontWeight = if (isHomeSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isHomeSelected) LuxuryGoldAccent else TextGrayMuted
                            )
                            if (isHomeSelected) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Box(
                                    modifier = Modifier
                                        .width(32.dp)
                                        .height(2.5.dp)
                                        .clip(RoundedCornerShape(2.dp))
                                        .background(LuxuryGoldAccent)
                                )
                            }
                        }
                    }
                }
            },
            containerColor = DeepEspressoDark
        ) { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentPadding = PaddingValues(horizontal = 18.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                // 1. Top Header: Chip on the left (RTL end), Title & Settings on the right (RTL start)
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp, bottom = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Motivational Chip on the left (RTL end)
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(ChipEspressoDark)
                                .border(1.dp, BorderEspressoDark, RoundedCornerShape(50))
                                .padding(horizontal = 12.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.MenuBook,
                                contentDescription = null,
                                tint = LuxuryGoldAccent,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "ركز.. فالانضباط يصنع الفرق",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.5.sp),
                                color = TextCreamLight.copy(alpha = 0.9f)
                            )
                        }

                        // Title "اليوم" + Gear Icon + Date Subtitle on the right (RTL start)
                        Column(horizontalAlignment = Alignment.End) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "اليوم",
                                    style = MaterialTheme.typography.headlineLarge.copy(fontSize = 30.sp),
                                    fontWeight = FontWeight.Bold,
                                    color = TextCreamLight
                                )
                                IconButton(
                                    onClick = onOpenSettings,
                                    modifier = Modifier
                                        .size(34.dp)
                                        .testTag("top_settings_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Settings,
                                        contentDescription = "الإعدادات",
                                        tint = LuxuryGoldAccent,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(2.dp))

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = todayDateFormatted.ifBlank { "السبت 14 يونيو 2025" },
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp),
                                    color = TextGrayMuted
                                )
                                Icon(
                                    imageVector = Icons.Default.CalendarToday,
                                    contentDescription = null,
                                    tint = LuxuryGoldAccent,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                }

                // 2. Stats Card (بطاقة إحصائيات سريعة)
                item {
                    Card(
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = CardEspressoDark),
                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderEspressoDark),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 18.dp, horizontal = 8.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Column 1: إجمالي المهام اليوم
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.weight(1f)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Text(
                                        text = "$totalTasksCount",
                                        style = MaterialTheme.typography.headlineMedium.copy(fontSize = 26.sp),
                                        fontWeight = FontWeight.Bold,
                                        color = LuxuryGoldAccent
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Icon(
                                        imageVector = Icons.Default.Assignment,
                                        contentDescription = null,
                                        tint = LuxuryGoldAccent,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "إجمالي المهام اليوم",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 12.sp),
                                    color = TextGrayMuted,
                                    textAlign = TextAlign.Center
                                )
                            }

                            // Vertical Divider
                            Box(
                                modifier = Modifier
                                    .width(1.dp)
                                    .height(48.dp)
                                    .background(BorderEspressoDark)
                            )

                            // Column 2: مهام مكتملة
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.weight(1f)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Text(
                                        text = "$completedCount",
                                        style = MaterialTheme.typography.headlineMedium.copy(fontSize = 26.sp),
                                        fontWeight = FontWeight.Bold,
                                        color = LuxuryGoldAccent
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = LuxuryGoldAccent,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "مهام مكتملة",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 12.sp),
                                    color = TextGrayMuted,
                                    textAlign = TextAlign.Center
                                )
                            }

                            // Vertical Divider
                            Box(
                                modifier = Modifier
                                    .width(1.dp)
                                    .height(48.dp)
                                    .background(BorderEspressoDark)
                            )

                            // Column 3: الوقت المخطط له
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.weight(1.15f)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Text(
                                        text = formattedDurationString,
                                        style = MaterialTheme.typography.headlineMedium.copy(fontSize = 22.sp),
                                        fontWeight = FontWeight.Bold,
                                        color = LuxuryGoldAccent
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Icon(
                                        imageVector = Icons.Default.Schedule,
                                        contentDescription = null,
                                        tint = LuxuryGoldAccent,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "الوقت المخطط له",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 12.sp),
                                    color = TextGrayMuted,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }

                // 3. بطاقة جدول المهام (Task Schedule Table Card)
                item {
                    Card(
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = CardEspressoDark),
                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderEspressoDark),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("task_schedule_card")
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp)
                        ) {
                            // Header of the card: Title & + إضافة مهمة button
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Add Task Pill Button
                                Row(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(50))
                                        .background(LuxuryGoldAccent)
                                        .clickable { onAddTaskClick() }
                                        .padding(horizontal = 14.dp, vertical = 7.dp)
                                        .testTag("add_task_header_button"),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = null,
                                        tint = DeepEspressoDark,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = "إضافة مهمة",
                                        style = MaterialTheme.typography.labelMedium.copy(fontSize = 12.5.sp),
                                        fontWeight = FontWeight.Bold,
                                        color = DeepEspressoDark
                                    )
                                }

                                // Section Title "جدول المهام" + Calendar Icon
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = "جدول المهام",
                                        style = MaterialTheme.typography.titleLarge.copy(fontSize = 19.sp),
                                        fontWeight = FontWeight.Bold,
                                        color = TextCreamLight
                                    )
                                    Icon(
                                        imageVector = Icons.Default.CalendarToday,
                                        contentDescription = null,
                                        tint = LuxuryGoldAccent,
                                        modifier = Modifier.size(19.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(18.dp))

                            // Table Columns Header (5 columns)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "المهمة",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 12.sp),
                                    color = TextGrayMuted,
                                    modifier = Modifier.weight(2.4f),
                                    textAlign = TextAlign.Start
                                )
                                Text(
                                    text = "الوقت من",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 12.sp),
                                    color = TextGrayMuted,
                                    modifier = Modifier.weight(1.2f),
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    text = "الوقت إلى",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 12.sp),
                                    color = TextGrayMuted,
                                    modifier = Modifier.weight(1.2f),
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    text = "المنبه",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 12.sp),
                                    color = TextGrayMuted,
                                    modifier = Modifier.weight(1.1f),
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    text = "إجراءات",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 12.sp),
                                    color = TextGrayMuted,
                                    modifier = Modifier.weight(1.2f),
                                    textAlign = TextAlign.Center
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Table Rows
                            if (tasks.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "لا توجد مهام مدخلة حتى الآن، اضغط على زر إضافة مهمة للبدء.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextGrayMuted,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            } else {
                                tasks.forEach { task ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 3.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(RowEspressoDark)
                                            .border(0.5.dp, BorderEspressoDark.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                                            .padding(horizontal = 10.dp, vertical = 12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        // 1. المهمة (Task Title)
                                        Text(
                                            text = task.title,
                                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                                            fontWeight = FontWeight.Medium,
                                            color = if (task.isCompleted) TextGrayMuted else TextCreamLight,
                                            textDecoration = if (task.isCompleted) TextDecoration.LineThrough else TextDecoration.None,
                                            modifier = Modifier
                                                .weight(2.4f)
                                                .clickable { onToggleCompletion(task) },
                                            maxLines = 2
                                        )

                                        // 2. الوقت من (Start Time)
                                        Text(
                                            text = if (task.startTime.isNotBlank()) task.startTime else "--:--",
                                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                                            color = if (task.startTime.isNotBlank()) TextCreamLight else TextGraySubtle,
                                            modifier = Modifier.weight(1.2f),
                                            textAlign = TextAlign.Center
                                        )

                                        // 3. الوقت إلى (End Time)
                                        Text(
                                            text = if (task.endTime.isNotBlank()) task.endTime else "--:--",
                                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                                            color = if (task.endTime.isNotBlank()) TextCreamLight else TextGraySubtle,
                                            modifier = Modifier.weight(1.2f),
                                            textAlign = TextAlign.Center
                                        )

                                        // 4. المنبه (Alarm Switch)
                                        Box(
                                            modifier = Modifier.weight(1.1f),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Switch(
                                                checked = task.isAlarmEnabled,
                                                onCheckedChange = { onToggleAlarm(task) },
                                                colors = SwitchDefaults.colors(
                                                    checkedThumbColor = LuxuryGoldAccent,
                                                    checkedTrackColor = LuxuryGoldContainer,
                                                    uncheckedThumbColor = TextGraySubtle,
                                                    uncheckedTrackColor = Color(0xFF26201A),
                                                    uncheckedBorderColor = BorderEspressoDark
                                                ),
                                                modifier = Modifier.size(width = 38.dp, height = 22.dp)
                                            )
                                        }

                                        // 5. إجراءات (Actions: Edit + Delete)
                                        Row(
                                            modifier = Modifier.weight(1.2f),
                                            horizontalArrangement = Arrangement.Center,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Edit,
                                                contentDescription = "تعديل",
                                                tint = TextGrayMuted,
                                                modifier = Modifier
                                                    .size(17.dp)
                                                    .clickable { onEditTask(task) }
                                                    .testTag("edit_task_${task.id}")
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Icon(
                                                imageVector = Icons.Default.DeleteOutline,
                                                contentDescription = "حذف",
                                                tint = TextGrayMuted,
                                                modifier = Modifier
                                                    .size(17.dp)
                                                    .clickable { onDeleteTask(task) }
                                                    .testTag("delete_task_${task.id}")
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 4. بطاقة اقتراحات ذكية (Smart Suggestions)
                item {
                    Card(
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = CardEspressoDark),
                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderEspressoDark),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("smart_suggestions_card")
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Section Header: Title + Glowing Golden Lightbulb Badge
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Lightbulb Circular Badge on the left (RTL end)
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF2B2215))
                                        .border(1.dp, LuxuryGoldAccent.copy(alpha = 0.3f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Lightbulb,
                                        contentDescription = null,
                                        tint = LuxuryGoldAccent,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                // Title on the right (RTL start)
                                Text(
                                    text = "اقتراحات لتنظيم يومك",
                                    style = MaterialTheme.typography.titleLarge.copy(fontSize = 18.sp),
                                    fontWeight = FontWeight.Bold,
                                    color = TextCreamLight
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            // Suggestion Items List (Pill shaped cards)
                            suggestions.forEach { suggestion ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(Color(0xFF221E19))
                                        .border(1.dp, Color(0xFF2E2721), RoundedCornerShape(20.dp))
                                        .clickable { onSuggestionAction(suggestion) }
                                        .padding(horizontal = 16.dp, vertical = 12.dp)
                                        .testTag("suggestion_pill_${suggestion.id}"),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    // Text on the right (RTL start)
                                    Text(
                                        text = suggestion.text,
                                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.5.sp, lineHeight = 18.sp),
                                        color = TextCreamLight.copy(alpha = 0.95f),
                                        modifier = Modifier.weight(1f)
                                    )

                                    Spacer(modifier = Modifier.width(12.dp))

                                    // Icon on the left (RTL end)
                                    Icon(
                                        imageVector = suggestion.icon,
                                        contentDescription = null,
                                        tint = LuxuryGoldAccent,
                                        modifier = Modifier.size(19.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}
