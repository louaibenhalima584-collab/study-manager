package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.TaskEntity
import com.example.data.local.TimerSessionEntity
import com.example.data.repository.TaskRepository
import com.example.security.SecurityManager
import com.example.suggestions.SmartSuggestionEngine
import com.example.suggestions.SuggestionActionType
import com.example.suggestions.SuggestionItem
import com.example.timer.TimerManager
import com.example.timer.TimerMethod
import com.example.timer.TimerPresets
import com.example.ui.navigation.Screen
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

data class TaskDialogState(
    val isOpen: Boolean = false,
    val taskToEdit: TaskEntity? = null
)

class MainViewModel(
    private val repository: TaskRepository,
    private val securityManager: SecurityManager,
    val timerManager: TimerManager = TimerManager()
) : ViewModel() {

    private val _currentScreen = MutableStateFlow<Screen>(
        if (!securityManager.hasSetPin()) {
            Screen.Welcome
        } else if (!securityManager.isUserSessionActive()) {
            Screen.PinLogin
        } else {
            Screen.Dashboard
        }
    )
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _themeMode = MutableStateFlow(securityManager.getDarkThemeMode())
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    private val _autoBreakEnabled = MutableStateFlow(securityManager.isAutoBreakEnabled())
    val autoBreakEnabled: StateFlow<Boolean> = _autoBreakEnabled.asStateFlow()

    private val _taskDialogState = MutableStateFlow(TaskDialogState())
    val taskDialogState: StateFlow<TaskDialogState> = _taskDialogState.asStateFlow()

    private val _selectedTab = MutableStateFlow(0) // 0: Dashboard/Home, 1: Tasks, 2: Timer
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _notificationMessage = MutableStateFlow<String?>(null)
    val notificationMessage: StateFlow<String?> = _notificationMessage.asStateFlow()

    val todayDateFormatted: String = run {
        try {
            val now = LocalDate.now()
            val formatter = DateTimeFormatter.ofPattern("EEEE، d MMMM", Locale("ar"))
            now.format(formatter)
        } catch (e: Exception) {
            "اليوم الدراسي"
        }
    }

    val todayTasks: StateFlow<List<TaskEntity>> = repository.getTasksForDate()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val smartSuggestions: StateFlow<List<SuggestionItem>> = todayTasks
        .combine(timerManager.state) { tasks, _ ->
            SmartSuggestionEngine.generateSuggestions(tasks)
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    init {
        viewModelScope.launch {
            repository.populateInitialDataIfEmpty()
        }
    }

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
        _authError.value = null
    }

    fun selectTab(tabIndex: Int) {
        _selectedTab.value = tabIndex
        when (tabIndex) {
            0, 1 -> navigateTo(Screen.Dashboard)
            2 -> navigateTo(Screen.TimerMethodSelect)
        }
    }

    fun onGoogleSignInSuccess(userName: String, userEmail: String) {
        securityManager.setGoogleAuthDone(userName, userEmail)
        _authError.value = null
        navigateTo(Screen.CreatePin)
    }

    fun onCreatePin(pin: String, confirmPin: String) {
        if (pin.length < 4) {
            _authError.value = "يجب أن تتكون كلمة المرور / رمز PIN من 4 خانات على الأقل"
            return
        }
        if (pin != confirmPin) {
            _authError.value = "كلمة المرور غير متطابقة، يرجى إعادة المحاولة"
            return
        }
        securityManager.savePin(pin)
        _authError.value = null
        navigateTo(Screen.Dashboard)
    }

    fun onPinLogin(pin: String) {
        if (securityManager.verifyPin(pin)) {
            _authError.value = null
            navigateTo(Screen.Dashboard)
        } else {
            _authError.value = "رمز الدخول غير صحيح، يرجى المحاولة مرة أخرى"
        }
    }

    fun onForgotPinReset() {
        securityManager.resetPin()
        navigateTo(Screen.Welcome)
        _notificationMessage.value = "تمت إعادة ضبط رمز المرور. يرجى تسجيل الدخول مجدداً."
    }

    fun openAddTaskDialog() {
        _taskDialogState.value = TaskDialogState(isOpen = true, taskToEdit = null)
    }

    fun openEditTaskDialog(task: TaskEntity) {
        _taskDialogState.value = TaskDialogState(isOpen = true, taskToEdit = task)
    }

    fun closeTaskDialog() {
        _taskDialogState.value = TaskDialogState(isOpen = false, taskToEdit = null)
    }

    fun saveTask(
        title: String,
        subject: String,
        startTime: String,
        endTime: String,
        priority: String,
        notes: String,
        isAlarmEnabled: Boolean
    ) {
        val duration = calculateDurationMinutes(startTime, endTime)
        val today = LocalDate.now().toString()
        val currentEdit = _taskDialogState.value.taskToEdit

        viewModelScope.launch {
            if (currentEdit != null) {
                val updated = currentEdit.copy(
                    title = title.trim(),
                    subject = subject.trim(),
                    startTime = startTime.trim(),
                    endTime = endTime.trim(),
                    durationMinutes = duration,
                    priority = priority,
                    notes = notes.trim(),
                    isAlarmEnabled = isAlarmEnabled
                )
                repository.updateTask(updated)
            } else {
                val newTask = TaskEntity(
                    title = title.trim(),
                    subject = subject.trim(),
                    startTime = startTime.trim(),
                    endTime = endTime.trim(),
                    durationMinutes = duration,
                    priority = priority,
                    notes = notes.trim(),
                    isAlarmEnabled = isAlarmEnabled,
                    isCompleted = false,
                    date = today
                )
                repository.insertTask(newTask)
            }
            closeTaskDialog()
        }
    }

    fun toggleTaskAlarm(task: TaskEntity) {
        viewModelScope.launch {
            val newState = !task.isAlarmEnabled
            repository.toggleAlarm(task.id, newState)
            _notificationMessage.value = if (newState) {
                "تم تفعيل التنبيه لمهمة ${task.subject}"
            } else {
                "تم إيقاف التنبيه لمهمة ${task.subject}"
            }
        }
    }

    fun toggleTaskCompletion(task: TaskEntity) {
        viewModelScope.launch {
            repository.toggleCompletion(task.id, !task.isCompleted)
        }
    }

    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.deleteTask(task)
        }
    }

    fun startTaskTimer(task: TaskEntity) {
        timerManager.startTaskSession(
            taskId = task.id,
            subject = task.subject,
            taskTitle = task.title,
            durationMinutes = task.durationMinutes,
            autoTransition = _autoBreakEnabled.value
        )
        _selectedTab.value = 2
        navigateTo(Screen.ActiveTimer)
    }

    fun selectTimerMethod(method: TimerMethod, subject: String = "جلسة مذاكرة عامة") {
        timerManager.configureMethod(
            method = method,
            subject = subject,
            autoTransition = _autoBreakEnabled.value
        )
        timerManager.startOrResumeTimer()
        navigateTo(Screen.ActiveTimer)
    }

    fun finishCurrentSession() {
        val timerState = timerManager.state.value
        viewModelScope.launch {
            val session = TimerSessionEntity(
                taskId = timerState.linkedTaskId,
                subject = timerState.subjectName,
                taskTitle = timerState.taskTitle,
                methodName = timerState.currentMethod.arabicTitle,
                focusMinutes = timerState.currentMethod.focusMinutes,
                breakMinutes = timerState.currentMethod.breakMinutes,
                completedCycles = timerState.currentCycle
            )
            repository.recordTimerSession(session)

            if (timerState.linkedTaskId != null) {
                repository.toggleCompletion(timerState.linkedTaskId, true)
            }

            timerManager.stopTimer()
            navigateTo(Screen.Dashboard)
            _selectedTab.value = 0
            _notificationMessage.value = "أحسنت! تم إكمال جلسة التركيز بنجاح."
        }
    }

    fun handleSuggestionAction(suggestion: SuggestionItem) {
        when (suggestion.actionType) {
            SuggestionActionType.START_NOW -> {
                if (suggestion.targetTaskId != null) {
                    val task = todayTasks.value.find { it.id == suggestion.targetTaskId }
                    if (task != null) {
                        startTaskTimer(task)
                        return
                    }
                }
                // Default start Pomodoro
                selectTimerMethod(TimerPresets.Pomodoro, "جلسة مراجعة سريعة")
            }
            SuggestionActionType.ADD_BREAK -> {
                // Open add task with Break preset
                openAddTaskDialog()
            }
            SuggestionActionType.SPLIT_TASK -> {
                if (suggestion.targetTaskId != null) {
                    val task = todayTasks.value.find { it.id == suggestion.targetTaskId }
                    if (task != null) {
                        openEditTaskDialog(task)
                    }
                }
            }
            SuggestionActionType.RESCHEDULE -> {
                navigateTo(Screen.Dashboard)
                _selectedTab.value = 1
            }
            SuggestionActionType.ENABLE_ALARM -> {
                if (suggestion.targetTaskId != null) {
                    val task = todayTasks.value.find { it.id == suggestion.targetTaskId }
                    if (task != null) {
                        toggleTaskAlarm(task)
                    }
                }
            }
            SuggestionActionType.NONE -> {}
        }
    }

    fun setDarkThemeMode(mode: String) {
        _themeMode.value = mode
        securityManager.setDarkThemeMode(mode)
    }

    fun setAutoBreak(enabled: Boolean) {
        _autoBreakEnabled.value = enabled
        securityManager.setAutoBreakEnabled(enabled)
    }

    fun logout() {
        securityManager.lockSession()
        navigateTo(Screen.PinLogin)
    }

    fun clearNotificationMessage() {
        _notificationMessage.value = null
    }

    fun getUserName(): String = securityManager.getUserName()
    fun getUserEmail(): String = securityManager.getUserEmail()

    private fun calculateDurationMinutes(start: String, end: String): Int {
        val startMins = toMinutes(start)
        val endMins = toMinutes(end)
        val diff = endMins - startMins
        return if (diff > 0) diff else 60
    }

    private fun toMinutes(timeStr: String): Int {
        val parts = timeStr.trim().split(":")
        val h = parts.getOrNull(0)?.toIntOrNull() ?: 0
        val m = parts.getOrNull(1)?.toIntOrNull() ?: 0
        return h * 60 + m
    }
}
