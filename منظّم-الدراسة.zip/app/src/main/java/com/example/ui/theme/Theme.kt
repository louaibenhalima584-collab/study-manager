package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = LuxuryGoldAccent,
    onPrimary = DeepEspressoDark,
    primaryContainer = LuxuryGoldContainer,
    onPrimaryContainer = LuxuryGoldOnContainer,
    secondary = LuxuryGoldMuted,
    onSecondary = DeepEspressoDark,
    secondaryContainer = ChipEspressoDark,
    onSecondaryContainer = TextCreamLight,
    tertiary = SuccessSoftGreen,
    onTertiary = DeepEspressoDark,
    background = DeepEspressoDark,
    onBackground = TextCreamLight,
    surface = CardEspressoDark,
    onSurface = TextCreamLight,
    surfaceVariant = RowEspressoDark,
    onSurfaceVariant = TextGrayMuted,
    outline = BorderEspressoDark,
    outlineVariant = BorderEspressoSubtle
)

private val LightColorScheme = lightColorScheme(
    primary = LuxuryGoldMuted,
    onPrimary = Color.Black,
    primaryContainer = SurfaceVariantLinen,
    onPrimaryContainer = TextPrimaryLinen,
    secondary = LuxuryGoldAccent,
    onSecondary = Color.Black,
    secondaryContainer = SurfaceVariantLinen,
    onSecondaryContainer = TextPrimaryLinen,
    tertiary = AccentTerracotta,
    onTertiary = Color.White,
    background = LinenLight,
    onBackground = TextPrimaryLinen,
    surface = SurfaceWhite,
    onSurface = TextPrimaryLinen,
    surfaceVariant = SurfaceVariantLinen,
    onSurfaceVariant = TextSecondaryLinen,
    outline = BorderLinen,
    outlineVariant = BorderLinen
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to Elegant Dark mode as requested
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
