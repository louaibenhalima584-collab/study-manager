package com.example.ui.timer

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreTime
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.timer.TimerRunState
import com.example.timer.TimerSessionType
import com.example.timer.TimerUIState

@Composable
fun ActiveTimerScreen(
    timerState: TimerUIState,
    onStartResume: () -> Unit,
    onPause: () -> Unit,
    onAddFiveMinutes: () -> Unit,
    onStartBreak: () -> Unit,
    onSkipBreak: () -> Unit,
    onStartNextFocusCycle: () -> Unit,
    onFinishSession: () -> Unit,
    onCloseToDashboard: () -> Unit
) {
    var showConfirmFinishDialog by remember { mutableStateOf(false) }

    val isBreakPhase = timerState.sessionType == TimerSessionType.BREAK
    val isRunning = timerState.runState == TimerRunState.RUNNING

    val accentColor = if (isBreakPhase) Color(0xFF6B8A72) else MaterialTheme.colorScheme.primary
    val ringTrackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 24.dp, vertical = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Navigation Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onCloseToDashboard,
                        modifier = Modifier.testTag("timer_close_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق المؤقت",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = timerState.currentMethod.arabicTitle,
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "الجلسة ${timerState.currentCycle} من ${timerState.currentMethod.totalCycles}",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    // Spacer balance
                    Box(modifier = Modifier.size(48.dp))
                }

                // Middle Content: Subject Title, Circular Progress & Big Timer
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Subject Pill
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(accentColor.copy(alpha = 0.14f))
                            .border(0.8.dp, accentColor.copy(alpha = 0.35f), RoundedCornerShape(20.dp))
                            .padding(horizontal = 18.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = timerState.subjectName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = accentColor
                        )
                    }

                    if (timerState.taskTitle.isNotBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = timerState.taskTitle,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }

                    Spacer(modifier = Modifier.height(36.dp))

                    // Circular Progress & Clock
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(270.dp)
                            .testTag("circular_timer_display")
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val strokeWidth = 14.dp.toPx()
                            // Track circle
                            drawCircle(
                                color = ringTrackColor,
                                style = Stroke(width = strokeWidth)
                            )
                            // Progress arc
                            val sweepAngle = 360f * timerState.progress.coerceIn(0f, 1f)
                            drawArc(
                                color = accentColor,
                                startAngle = -90f,
                                sweepAngle = sweepAngle,
                                useCenter = false,
                                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = timerState.formattedTime,
                                style = MaterialTheme.typography.displayLarge.copy(fontSize = 54.sp),
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground,
                                letterSpacing = 1.sp
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = if (isBreakPhase) "الاستراحة" else "التركيز",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = accentColor
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(28.dp))

                    // Status Banner when phase finishes
                    if (timerState.runState == TimerRunState.FOCUS_COMPLETED) {
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            ),
                            border = CardDefaults.outlinedCardBorder().copy(
                                brush = androidx.compose.ui.graphics.SolidColor(Color(0xFF5A7864))
                            ),
                            modifier = Modifier.fillMaxWidth(0.9f)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "انتهت جلسة التركيز! حان وقت الاستراحة ☕",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF5A7864),
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = onStartBreak,
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("بدء الاستراحة")
                                    }
                                    OutlinedButton(
                                        onClick = onSkipBreak,
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("تخطي الاستراحة")
                                    }
                                }
                            }
                        }
                    } else if (timerState.runState == TimerRunState.BREAK_COMPLETED) {
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            ),
                            border = CardDefaults.outlinedCardBorder().copy(
                                brush = androidx.compose.ui.graphics.SolidColor(Color(0xFFB55D3A))
                            ),
                            modifier = Modifier.fillMaxWidth(0.9f)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "انتهت فترة الاستراحة، هل أنت جاهز لمتابعة التركيز؟",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFB55D3A),
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = onStartNextFocusCycle,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("بدء دورة التركيز التالية")
                                }
                            }
                        }
                    }
                }

                // Bottom Action Buttons: [ Pause / Resume ] [ إنهاء ] [ +5 دقائق ]
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // +5 Min Button
                        OutlinedButton(
                            onClick = onAddFiveMinutes,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .height(50.dp)
                                .testTag("timer_add_five_mins"),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.MoreTime,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "+5 دقائق",
                                    style = MaterialTheme.typography.titleMedium.copy(fontSize = 14.sp)
                                )
                            }
                        }

                        // Primary Pause / Play Button
                        Button(
                            onClick = {
                                if (isRunning) onPause() else onStartResume()
                            },
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .height(56.dp)
                                .testTag("timer_play_pause_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = accentColor,
                                contentColor = Color.White
                            ),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 24.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = if (isRunning) "إيقاف مؤقت" else "متابعة",
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isRunning) "إيقاف مؤقت" else "متابعة",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Finish Button [ إنهاء ]
                        OutlinedButton(
                            onClick = { showConfirmFinishDialog = true },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .height(50.dp)
                                .testTag("timer_finish_button"),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Stop,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp),
                                    tint = MaterialTheme.colorScheme.error
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "إنهاء",
                                    style = MaterialTheme.typography.titleMedium.copy(fontSize = 14.sp),
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }

            // Confirm Finish Dialog
            if (showConfirmFinishDialog) {
                AlertDialog(
                    onDismissRequest = { showConfirmFinishDialog = false },
                    title = {
                        Text(
                            text = "إنهاء جلسة المذاكرة",
                            style = MaterialTheme.typography.titleLarge
                        )
                    },
                    text = {
                        Text(
                            text = "هل ترغب في إنهاء الجلسة وتسجيلها كجلسة منجزة؟ سيتم حفظ تقدمك وتحديث حالة المهمة المرتبطة.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                showConfirmFinishDialog = false
                                onFinishSession()
                            }
                        ) {
                            Text("نعم، إنهاء وتسجيل")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showConfirmFinishDialog = false }) {
                            Text("متابعة الجلسة")
                        }
                    }
                )
            }
        }
    }
}
