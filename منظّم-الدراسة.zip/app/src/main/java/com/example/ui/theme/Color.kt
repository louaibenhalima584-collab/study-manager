package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Luxury Warm Dark & Golden Cream Palette
// Primary Canvas: Warm Dark Espresso / Charcoal Brown
val DeepEspressoDark = Color(0xFF0F0D0A)
val CardEspressoDark = Color(0xFF1C1815)
val RowEspressoDark = Color(0xFF14110E)
val ChipEspressoDark = Color(0xFF221C17)
val BorderEspressoDark = Color(0xFF2B2520)
val BorderEspressoSubtle = Color(0xFF383029)

// Luxury Golden Cream Accents
val LuxuryGoldAccent = Color(0xFFF0D9A6)
val LuxuryGoldMuted = Color(0xFFDEC285)
val LuxuryGoldContainer = Color(0xFF2E261B)
val LuxuryGoldOnContainer = Color(0xFFF7E7C4)

// Text Colors
val TextCreamLight = Color(0xFFFAF7F2)
val TextGrayMuted = Color(0xFF9E978E)
val TextGraySubtle = Color(0xFF6E6860)

// Success & Secondary Colors
val SuccessSoftGreen = Color(0xFF88B088)
val AccentTerracotta = Color(0xFFB55D3A)
val AccentSlateBlue = Color(0xFF4D6073)

// Light Mode Support
val LinenLight = Color(0xFFF5F2ED)
val SurfaceWhite = Color(0xFFFFFFFF)
val SurfaceVariantLinen = Color(0xFFEFEBE4)
val BorderLinen = Color(0xFFE5E0D8)
val TextPrimaryLinen = Color(0xFF1C1C1C)
val TextSecondaryLinen = Color(0xFF6B7280)


