package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.example.alarm.AlarmScheduler
import com.example.data.local.AppDatabase
import com.example.receiver.TaskAlarmReceiver
import com.example.security.SecurityManager

class StudyPlannerApp : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var securityManager: SecurityManager
        private set

    lateinit var alarmScheduler: AlarmScheduler
        private set

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.getDatabase(this)
        securityManager = SecurityManager(this)
        alarmScheduler = AlarmScheduler(this)
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                TaskAlarmReceiver.CHANNEL_ID,
                TaskAlarmReceiver.CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "قناة إشعارات تنبيهات المهام والمذاكرة اليومية"
                enableLights(true)
                enableVibration(true)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }
}
