package com.example.suggestions

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Coffee
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.data.local.TaskEntity

data class SuggestionItem(
    val id: String,
    val icon: ImageVector,
    val text: String,
    val actionText: String? = null,
    val targetTaskId: Long? = null,
    val actionType: SuggestionActionType = SuggestionActionType.NONE
)

enum class SuggestionActionType {
    NONE,
    START_NOW,
    ADD_BREAK,
    RESCHEDULE,
    SPLIT_TASK,
    ENABLE_ALARM
}

object SmartSuggestionEngine {

    fun generateSuggestions(tasks: List<TaskEntity>): List<SuggestionItem> {
        val list = mutableListOf<SuggestionItem>()

        // 1. Break suggestion (Coffee)
        list.add(
            SuggestionItem(
                id = "break_suggestion",
                icon = Icons.Default.Coffee,
                text = "خذ استراحة قصيرة بعد جلستين متتاليتين لتحافظ على تركيزك.",
                actionText = "استراحة ٥ د",
                actionType = SuggestionActionType.ADD_BREAK
            )
        )

        // 2. Physics / Subject review suggestion (Book)
        val physicsTask = tasks.find { it.subject.contains("فيزياء") || it.title.contains("فيزياء") }
        list.add(
            SuggestionItem(
                id = "subject_review",
                icon = Icons.Default.MenuBook,
                text = "يمكنك استغلال الساعة القادمة لمراجعة درس الفيزياء.",
                actionText = "ابدأ الآن",
                targetTaskId = physicsTask?.id,
                actionType = SuggestionActionType.START_NOW
            )
        )

        // 3. Early morning math review (Clock)
        list.add(
            SuggestionItem(
                id = "math_early_review",
                icon = Icons.Default.Schedule,
                text = "حاول البدء بمراجعة الرياضيات في الوقت المبكر غدًا لزيادة التركيز.",
                actionText = "تذكير",
                actionType = SuggestionActionType.RESCHEDULE
            )
        )

        // 4. Task splitting suggestion (List)
        list.add(
            SuggestionItem(
                id = "split_large_tasks",
                icon = Icons.Default.FormatListBulleted,
                text = "قسم المهام الكبيرة إلى أجزاء أصغر لتسهيل إنجازها.",
                actionText = "تقسيم",
                actionType = SuggestionActionType.SPLIT_TASK
            )
        )

        // 5. Reading & Analytics suggestion (Chart)
        list.add(
            SuggestionItem(
                id = "reading_analytics",
                icon = Icons.Default.BarChart,
                text = "زد من وقت القراءة يومياً لتحسين فهمك واستيعابك.",
                actionText = "إحصائيات",
                actionType = SuggestionActionType.NONE
            )
        )

        return list
    }
}

